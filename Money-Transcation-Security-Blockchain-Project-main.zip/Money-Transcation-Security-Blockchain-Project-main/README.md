# Money-Transcation-Security-Blockchain-Project
Protection and Security of Transaction between friends with help of Blockchain. Project Code, Project PPT, Report and Synopsis for College Project(Final Year Project). 

### PPT: [Link](https://github.com/Vatshayan/Blockchain-Final-Year-Project/blob/main/Blockchain%20Money%20PPT.pdf)

### Demo:


https://user-images.githubusercontent.com/28294942/161795296-c79508aa-3c91-4942-a797-b7b9ab601a03.mov



## ABSTRACT:
Transcation between friends is secured by using blockchain technology. Here we will use see how transcation is secured and protected. Project is in python Programming. 



Blockchain is a system of recording information in a way that makes it difficult or impossible to change, hack, or cheat the system.

A blockchain is essentially a digital ledger of transactions that is duplicated and distributed across the entire network of computer systems on the blockchain. Each block in the chain contains a number of transactions, and every time a new transaction occurs on the blockchain, a record of that transaction is added to every participant’s ledger. 

### Blocks
Every chain consists of multiple blocks and each block has three basic elements:

The data in the block.
A 32-bit whole number called a nonce. The nonce is randomly generated when a block is created, which then generates a block header hash. 
The hash is a 256-bit number wedded to the nonce. It must start with a huge number of zeroes (i.e., be extremely small).
When the first block of a chain is created, a nonce generates the cryptographic hash. The data in the block is considered signed and forever tied to the nonce and hash unless it is mined.  

### Nodes
One of the most important concepts in blockchain technology is decentralization. No one computer or organization can own the chain. Instead, it is a distributed ledger via the nodes connected to the chain. Nodes can be any kind of electronic device that maintains copies of the blockchain and keeps the network functioning. 

Every node has its own copy of the blockchain and the network must algorithmically approve any newly mined block for the chain to be updated, trusted and verified. Since blockchains are transparent, every action in the ledger can be easily checked and viewed. Each participant is given a unique alphanumeric identification number that shows their transactions.

Combining public information with a system of checks-and-balances helps the blockchain maintain integrity and creates trust among users. Essentially, blockchains can be thought of as the scaleability of trust via technology. 

_________________________________________________________________________________________________________________________________________________


Hi there, 

**You Can use this Beautiful Project for your college Project and get good marks too.**

Email me Now **vatshayan007@gmail.com** to get this Full Project Code, PPT, Report, Synopsis, Video Presentation and Research paper of this Project.

💌 Feel free to contact me for any kind of help on any projects.
 
### HOW TO RUN THE PROJECT-
⚡ Email me at **vatshayan007@gmail.com** to get a detailed Guide report with Code to run the project with source Code.

### Need Code, Documents & Explanation video ? 

## How to Reach me :

### Mail : vatshayan007@gmail.com 

### WhatsApp: **+91 9310631437** (Helping 24*7) **[CHAT](https://wa.me/message/CHWN2AHCPMAZK1)** 

### Website : https://www.finalproject.in/

### 1000 Computer Science Projects : https://www.computer-science-project.in/

Mail/Message me for Projects Help 🙏🏻

### Top blockchain projects : https://vatshayan.medium.com/top-3-blockchain-final-year-projects-e910c25403a4
